/**
 * Host surface for the-office.
 *
 * Office-themed co-op: each controller adopts a "player" persona with its
 * own capabilities, and they cooperate on pending tasks that appear in
 * `TaskSidebar`. `GameCanvas` renders the 2D office floor; the rest of the
 * host is chrome over the networked `spaceStore` state and the declared
 * simulation (`game/engine/office-simulation.ts`), which plays the match.
 */
import { useHostAudioMutePreference } from "@air-jam/sdk";
import { HostPreviewControllerWorkspace } from "@air-jam/sdk/preview";
import { HostMuteButton, SurfaceViewport } from "@air-jam/sdk/ui";
import { OfficeHostGameplaySurface } from "./components/host-gameplay-surface";
import { OfficeHostOverlays } from "./components/host-overlays";
import { OfficeHostPlayerStrip } from "./components/host-player-strip";
import { OfficeHostTopHud } from "./components/host-top-hud";
import { useOfficeHostSession } from "./hooks/use-office-host-session";
import { useOfficeTimeRemainingMs } from "./hooks/use-office-match-view";

export function HostView() {
  const session = useOfficeHostSession();
  const audioPreference = useHostAudioMutePreference("the-office");
  const timeRemainingMs = useOfficeTimeRemainingMs();

  return (
    <>
      <SurfaceViewport className="bg-[var(--airjam-color-paper-cream)]">
        <div className="relative flex h-full w-full flex-col overflow-hidden p-2">
          <OfficeHostTopHud timeRemainingMs={timeRemainingMs} />
          <OfficeHostGameplaySurface
            muted={audioPreference.muted}
            session={session}
          />
          <OfficeHostPlayerStrip />
          <OfficeHostOverlays session={session} />
        </div>
      </SurfaceViewport>
      <HostPreviewControllerWorkspace
        dockAccessory={
          <HostMuteButton
            muted={audioPreference.muted}
            onToggle={audioPreference.toggleMuted}
          />
        }
      />
    </>
  );
}
