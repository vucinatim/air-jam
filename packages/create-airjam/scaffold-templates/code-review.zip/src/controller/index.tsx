import { useAirJamController, useAirJamStore } from "@air-jam/sdk";
import { ControllerPlayerNameField, SurfaceViewport } from "@air-jam/sdk/ui";
import { gameStore } from "../game/stores";
import { ControllerHeader } from "./components/controller-header";
import { EndedPanel } from "./components/ended-panel";
import { LobbyPanel } from "./components/lobby-panel";
import { PausedPanel } from "./components/paused-panel";
import { PlayingControls } from "./components/playing-controls";
import { useCodeReviewMovement } from "./hooks/use-code-review-movement";

export function ControllerView() {
  const connectionStatus = useAirJamController(
    (state) => state.connectionStatus,
  );
  const runtimeState = useAirJamController((state) => state.runtimeState);
  const matchPhase = useAirJamStore(gameStore, (state) => state.matchPhase);

  const canUseGameplayControls =
    connectionStatus === "connected" &&
    matchPhase === "playing" &&
    runtimeState === "playing";
  const desiredOrientation =
    matchPhase === "playing" ? "landscape" : "portrait";
  const { movementMode, motionStatus, enableTilt, useTouch } =
    useCodeReviewMovement({ enabled: canUseGameplayControls });

  return (
    <div className="controller-view-shell">
      <SurfaceViewport orientation={desiredOrientation}>
        <div className="pixel-font flex h-full w-full flex-col">
          <ControllerHeader />

          {matchPhase === "lobby" ? (
            <ControllerPlayerNameField
              className="border-b-4 border-zinc-800 bg-zinc-950 px-3 py-2"
              labelClassName="text-[9px] font-black tracking-[0.2em] text-zinc-500 uppercase"
              inputClassName="pixel-font w-full rounded-none border-4 border-zinc-600 bg-black px-2 py-2 text-sm text-white outline-none placeholder:text-zinc-600 focus:border-zinc-400"
            />
          ) : null}

          {matchPhase === "ended" ? (
            <EndedPanel />
          ) : matchPhase === "lobby" ? (
            <LobbyPanel />
          ) : canUseGameplayControls ? (
            <PlayingControls
              movementMode={movementMode}
              motionStatus={motionStatus}
              onEnableTilt={enableTilt}
              onUseTouch={useTouch}
            />
          ) : (
            <PausedPanel />
          )}
        </div>
      </SurfaceViewport>
    </div>
  );
}
