import {
  getUniqueSongCountForBuckets,
  songBuckets,
} from "@/game/content/song-bank";
import { isMatchReadyToStart } from "@/game/domain/match-readiness";
import {
  createEmptyScore,
  getLabelForPlayer,
} from "@/game/domain/player-utils";
import { gameStore } from "@/game/stores";
import { cn } from "@/game/ui/classes";
import { PlayerAvatarWithFire } from "@/game/ui/player-avatar-with-fire";
import { VerticalLogo } from "@/game/ui/vertical-logo";
import { MenuVideoBackground } from "@/host/components/menu-video-background";
import { useAirJamHost, useAirJamStore } from "@air-jam/sdk";
import {
  JoinQrOverlay,
  JoinUrlControls,
  LifecycleActionGroup,
  useHostJoinControls,
} from "@air-jam/sdk/ui";
import { AnimatePresence, motion } from "framer-motion";

const centerVariants = {
  initial: { opacity: 0, scale: 0.96 },
  animate: { opacity: 1, scale: 1 },
  exit: { opacity: 0, scale: 0.96 },
};

const playerCardVariants = {
  initial: { opacity: 0, y: 20, scale: 0.9 },
  animate: { opacity: 1, y: 0, scale: 1 },
  exit: { opacity: 0, y: -10, scale: 0.9 },
};

export const HostLobby = () => {
  const host = useAirJamHost();
  const roomId = useAirJamHost((state) => state.roomId);
  const lastError = useAirJamHost((state) => state.lastError);
  const players = useAirJamHost((state) => state.players);
  const phase = useAirJamStore(gameStore, (state) => state.phase);
  const playerOrder = useAirJamStore(gameStore, (state) => state.playerOrder);
  const playerLabelById = useAirJamStore(
    gameStore,
    (state) => state.playerLabelById,
  );
  const readyByPlayerId = useAirJamStore(
    gameStore,
    (state) => state.readyByPlayerId,
  );
  const totalRounds = useAirJamStore(gameStore, (state) => state.totalRounds);
  const selectedSongBucketIds = useAirJamStore(
    gameStore,
    (state) => state.selectedSongBucketIds,
  );
  const scoreboardByPlayerId = useAirJamStore(
    gameStore,
    (state) => state.scoreboardByPlayerId,
  );
  const actions = gameStore.actions;
  const readyCount = playerOrder.filter(
    (playerId) => readyByPlayerId[playerId],
  ).length;
  const uniqueSongCount = getUniqueSongCountForBuckets(selectedSongBucketIds);
  const hasEnoughSongs = uniqueSongCount >= totalRounds;
  const canStartMatch = isMatchReadyToStart({
    phase,
    playerIds: playerOrder,
    readyByPlayerId,
    hasEnoughSongs,
  });
  const hostJoinControls = useHostJoinControls({
    joinUrl: host.joinUrl,
    canStartMatch,
    onStartMatch: () => actions.startMatch(),
  });
  const hasPlayers = playerOrder.length > 0;
  const allReady = readyCount === playerOrder.length && readyCount > 0;

  return (
    <motion.div
      key="lobby"
      className="absolute inset-0"
      variants={centerVariants}
      initial="initial"
      animate="animate"
      exit="exit"
      transition={{ duration: 0.4 }}
    >
      <div className="relative h-full w-full overflow-hidden">
        <MenuVideoBackground className="absolute inset-0 z-0" />
        <div className="bg-background/40 pointer-events-none absolute inset-0 z-1" />

        <div
          className="lbs-lobby-layout relative z-2"
          data-has-players={hasPlayers}
        >
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1, duration: 0.6 }}
            className="lbs-lobby-intro"
          >
            <VerticalLogo className="lbs-lobby-logo text-foreground" />
            <p className="lbs-lobby-tagline text-muted-foreground text-center text-lg">
              Destroy your friends. Musically speaking, of course.
            </p>
            <motion.div
              layout
              className={cn(
                "lbs-lobby-join flex w-full flex-col items-center gap-3",
                hasPlayers && "opacity-80",
              )}
              transition={{
                layout: { type: "spring", stiffness: 300, damping: 30 },
              }}
            >
              {lastError && (
                <p className="text-destructive max-w-[340px] text-center text-xs">
                  {lastError}
                </p>
              )}
              <p
                className={cn(
                  "text-muted-foreground",
                  hasPlayers ? "text-sm" : "text-lg",
                )}
              >
                {hasPlayers
                  ? "More friends? Join from your phone."
                  : "Join from your phone to play."}
              </p>
              <JoinUrlControls
                value={hostJoinControls.joinUrlValue}
                label="Controller link"
                copied={hostJoinControls.copied}
                onCopy={hostJoinControls.handleCopy}
                onOpen={hostJoinControls.handleOpen}
                qrVisible={hostJoinControls.joinQrVisible}
                onToggleQr={hostJoinControls.toggleJoinQr}
                helperText="Copy or open the controller URL for quick joins."
                className="w-full"
                inputClassName="border-border/30 bg-card/40 text-foreground"
                buttonClassName="border-border/30 bg-background/60 text-foreground hover:bg-background/80"
              />
            </motion.div>
          </motion.div>

          <div className="lbs-lobby-panel">
            <div className="lbs-lobby-categories">
              {songBuckets.map((bucket) => {
                const selected = selectedSongBucketIds.includes(bucket.id);

                return (
                  <button
                    key={bucket.id}
                    type="button"
                    aria-pressed={selected}
                    onClick={() =>
                      actions.toggleSongBucket({ bucketId: bucket.id })
                    }
                    className={cn(
                      "flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2 text-xs font-black tracking-[0.08em] uppercase backdrop-blur-sm transition-all",
                      selected
                        ? "border-primary bg-primary/30 text-foreground ring-primary/40 ring-1"
                        : "border-border/30 bg-background/35 text-muted-foreground hover:bg-background/55",
                    )}
                  >
                    <span
                      className={cn(
                        "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border text-[10px] leading-none",
                        selected
                          ? "border-primary bg-primary text-primary-foreground"
                          : "border-muted-foreground/50",
                      )}
                      aria-hidden="true"
                    >
                      {selected ? "✓" : ""}
                    </span>
                    <span>{bucket.label}</span>
                  </button>
                );
              })}
            </div>
            <p
              className={cn(
                "text-center text-xs font-bold tracking-[0.12em] uppercase",
                hasEnoughSongs ? "text-muted-foreground" : "text-destructive",
              )}
            >
              {hasEnoughSongs
                ? `${selectedSongBucketIds.length}/${songBuckets.length} categories selected · ${uniqueSongCount} unique songs`
                : `Need ${totalRounds - uniqueSongCount} more unique songs for ${totalRounds} rounds`}
            </p>

            {hasPlayers && (
              <motion.div
                className="flex w-full flex-col items-center gap-4"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                <div className="lbs-lobby-players">
                  <AnimatePresence mode="popLayout">
                    {playerOrder.map((playerId, index) => {
                      const player =
                        players.find((entry) => entry.id === playerId) ?? null;
                      const isReady = readyByPlayerId[playerId] ?? false;
                      const score =
                        scoreboardByPlayerId[playerId] ?? createEmptyScore();

                      return (
                        <motion.div
                          key={playerId}
                          layout
                          variants={playerCardVariants}
                          initial="initial"
                          animate="animate"
                          exit="exit"
                          transition={{
                            layout: {
                              type: "spring",
                              stiffness: 400,
                              damping: 30,
                            },
                            delay: index * 0.05,
                          }}
                          className={cn(
                            "lbs-lobby-player flex min-w-0 flex-col items-center gap-2 rounded-2xl border px-4 py-3 backdrop-blur-md transition-all",
                            isReady
                              ? "border-primary/40 bg-primary/10"
                              : "border-border/40 bg-card/40",
                          )}
                        >
                          <div className="relative">
                            {player ? (
                              <PlayerAvatarWithFire
                                player={player}
                                size="sm"
                                showFire={score.hasStreakFire}
                              />
                            ) : (
                              <div className="bg-muted flex h-10 w-10 items-center justify-center rounded-full text-base font-bold">
                                {getLabelForPlayer(
                                  playerId,
                                  playerLabelById,
                                ).charAt(0)}
                              </div>
                            )}
                            <div
                              className={cn(
                                "absolute -right-0.5 -bottom-0.5 h-3.5 w-3.5 rounded-full border-2 transition-colors",
                                isReady
                                  ? "border-primary/30 bg-primary"
                                  : "border-card bg-muted-foreground/40",
                              )}
                            />
                          </div>
                          <span className="max-w-[100px] truncate text-sm font-medium">
                            {getLabelForPlayer(playerId, playerLabelById)}
                          </span>
                          <span
                            className={cn(
                              "text-xs font-medium",
                              isReady
                                ? "text-primary"
                                : "text-muted-foreground",
                            )}
                          >
                            {isReady ? "Ready" : "Waiting..."}
                          </span>
                        </motion.div>
                      );
                    })}
                  </AnimatePresence>
                </div>

                <motion.p
                  className="text-muted-foreground text-center text-lg"
                  key={allReady ? "all-ready" : "waiting"}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  {allReady
                    ? "All players ready!"
                    : `${readyCount}/${playerOrder.length} ready`}
                </motion.p>

                <LifecycleActionGroup
                  phase="lobby"
                  canInteract={canStartMatch}
                  onStart={hostJoinControls.handleStart}
                  startLabel="Start Match"
                  buttonClassName="rounded-2xl bg-primary px-8 py-3 text-base font-bold uppercase tracking-wider text-primary-foreground transition-transform active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40"
                  className="justify-center"
                />
              </motion.div>
            )}
          </div>
        </div>
        <JoinQrOverlay
          open={hostJoinControls.joinQrVisible}
          value={hostJoinControls.joinUrlValue}
          roomId={roomId}
          onClose={hostJoinControls.hideJoinQr}
          description="Scan with your phone to join Last Band Standing as a controller."
        />
      </div>
    </motion.div>
  );
};
