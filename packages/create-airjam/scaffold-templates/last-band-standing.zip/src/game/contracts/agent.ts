import {
  agentAction,
  agentActionInput,
  agentStore,
  defineAirJamAgentContract,
  defineAirJamAgentStores,
} from "@air-jam/sdk";
import { getRoundOptionLabel } from "../content/round-options";
import {
  defaultSelectedSongBucketIds,
  getSongById,
  getUniqueSongCountForBuckets,
  songBuckets,
  type SongBucketId,
} from "../content/song-bank";
import { isMatchReadyToStart } from "../domain/match-readiness";
import { rankPlayers } from "../domain/round-engine";

const DEFAULT_STORE_DOMAIN = "default";
const stores = defineAirJamAgentStores({
  [DEFAULT_STORE_DOMAIN]: agentStore<QuizState>(),
});
type GamePhase =
  | "lobby"
  | "match-countdown"
  | "round-active"
  | "round-reveal"
  | "game-over";
type RoundGuessKind = "artist" | "song-title";

interface PlayerScore {
  points: number;
  correct: number;
  wrong: number;
  totalResponseMs: number;
  answeredRounds: number;
}

interface PlayerAnswer {
  optionId: string;
  answeredAtMs: number;
}

interface RoundPlayerResult {
  optionId: string | null;
  responseMs: number | null;
  isCorrect: boolean;
  points: number;
}

interface ActiveRound {
  roundNumber: number;
  guessKind: RoundGuessKind;
  songId: string;
  expectedPlayerIds: string[];
  optionOrder: string[];
}

interface RoundReveal {
  roundNumber: number;
  songId: string;
  guessKind: RoundGuessKind;
  correctOptionId: string;
  correctOptionLabel: string;
  songTitle: string;
  songArtist: string;
  firstCorrectPlayerId: string | null;
  resultsByPlayerId: Record<string, RoundPlayerResult>;
}

interface QuizState {
  phase: GamePhase;
  playerOrder: string[];
  playerLabelById: Record<string, string>;
  readyByPlayerId: Record<string, boolean>;
  totalRounds: number;
  roundDurationSec: number;
  revealDurationSec: number;
  selectedSongBucketIds: SongBucketId[];
  playedSongKeys: string[];
  activePlayerIds: string[];
  completedRoundCount: number;
  currentRound: ActiveRound | null;
  answersByPlayerId: Record<string, PlayerAnswer>;
  roundReveal: RoundReveal | null;
  scoreboardByPlayerId: Record<string, PlayerScore>;
  finalRankingPlayerIds: string[];
}

const getLabelForPlayer = (
  playerId: string,
  playerLabelById: Record<string, string>,
): string => playerLabelById[playerId] ?? `Player ${playerId.slice(0, 4)}`;

const getRoundPrompt = (guessKind: RoundGuessKind): string => {
  return guessKind === "artist" ? "Who is the artist?" : "What song is this?";
};

const describeBucketSelection = (
  selectedBucketIds: readonly SongBucketId[],
  totalRounds: number,
) => {
  const uniqueSongCount = getUniqueSongCountForBuckets(selectedBucketIds);
  return {
    selectedBucketIds: [...selectedBucketIds],
    selectedBuckets: songBuckets.map((bucket) => ({
      id: bucket.id,
      label: bucket.label,
      selected: selectedBucketIds.includes(bucket.id),
      uniqueSongCount: getUniqueSongCountForBuckets([bucket.id]),
    })),
    uniqueSongCount,
    requiredSongCount: totalRounds,
    hasEnoughSongs: uniqueSongCount >= totalRounds,
  };
};

export const agentContract = defineAirJamAgentContract({
  stores,
  snapshotDescription:
    "Game-focused snapshot for Last Band Standing with lobby settings, player readiness, round prompts, answer options, reveal state, and scoreboard information.",
  projectSnapshot: (context) => {
    const { controllerId } = context;
    const state = context.stores.default;
    if (!state) {
      return {
        phase: "unavailable",
        summary: "Default replicated game store is not available yet.",
      };
    }

    const bucketSelection = describeBucketSelection(
      state.selectedSongBucketIds,
      state.totalRounds,
    );
    const readyCount = state.playerOrder.filter(
      (playerId) => state.readyByPlayerId[playerId],
    ).length;
    const canStartMatch = isMatchReadyToStart({
      phase: state.phase,
      playerIds: state.playerOrder,
      readyByPlayerId: state.readyByPlayerId,
      hasEnoughSongs: bucketSelection.hasEnoughSongs,
    });

    const players = state.playerOrder.map((playerId) => {
      const score = state.scoreboardByPlayerId[playerId] ?? null;
      return {
        id: playerId,
        label: getLabelForPlayer(playerId, state.playerLabelById),
        ready: state.readyByPlayerId[playerId] ?? false,
        active: state.activePlayerIds.includes(playerId),
        rank:
          state.finalRankingPlayerIds.length > 0
            ? state.finalRankingPlayerIds.indexOf(playerId) + 1
            : null,
        score: score
          ? {
              points: score.points,
              correct: score.correct,
              wrong: score.wrong,
              answeredRounds: score.answeredRounds,
            }
          : null,
      };
    });

    const round =
      state.currentRound === null
        ? null
        : (() => {
            const currentSong = getSongById(state.currentRound.songId);
            return {
              roundNumber: state.currentRound.roundNumber,
              guessKind: state.currentRound.guessKind,
              prompt: getRoundPrompt(state.currentRound.guessKind),
              songId: state.currentRound.songId,
              quizCategoryId: currentSong?.quizCategoryId ?? null,
              difficulty: currentSong?.difficulty ?? null,
              expectedPlayerIds: [...state.currentRound.expectedPlayerIds],
              answeredPlayerIds: Object.keys(state.answersByPlayerId),
              myAnswer:
                controllerId && state.answersByPlayerId[controllerId]
                  ? {
                      optionId: state.answersByPlayerId[controllerId].optionId,
                      answeredAtMs:
                        state.answersByPlayerId[controllerId].answeredAtMs,
                    }
                  : null,
              options: state.currentRound.optionOrder.map((optionSongId) => {
                const optionSong = getSongById(optionSongId);
                return {
                  id: optionSongId,
                  label: optionSong
                    ? getRoundOptionLabel(
                        optionSong,
                        state.currentRound!.guessKind,
                      )
                    : optionSongId,
                  quizCategoryId: optionSong?.quizCategoryId ?? null,
                };
              }),
            };
          })();

    const reveal =
      state.roundReveal === null
        ? null
        : (() => {
            const rankingPlayerIds = rankPlayers(state.scoreboardByPlayerId);
            const revealedSong = getSongById(state.roundReveal.songId);
            return {
              roundNumber: state.roundReveal.roundNumber,
              guessKind: state.roundReveal.guessKind,
              correctOptionId: state.roundReveal.correctOptionId,
              correctOptionLabel: state.roundReveal.correctOptionLabel,
              songTitle: state.roundReveal.songTitle,
              songArtist: state.roundReveal.songArtist,
              quizCategoryId: revealedSong?.quizCategoryId ?? null,
              difficulty: revealedSong?.difficulty ?? null,
              firstCorrectPlayerId: state.roundReveal.firstCorrectPlayerId,
              firstCorrectPlayerLabel: state.roundReveal.firstCorrectPlayerId
                ? getLabelForPlayer(
                    state.roundReveal.firstCorrectPlayerId,
                    state.playerLabelById,
                  )
                : null,
              myResult:
                controllerId &&
                state.roundReveal.resultsByPlayerId[controllerId]
                  ? state.roundReveal.resultsByPlayerId[controllerId]
                  : null,
              results: rankingPlayerIds.map((playerId, index) => ({
                playerId,
                playerLabel: getLabelForPlayer(playerId, state.playerLabelById),
                rank: index + 1,
                ...state.roundReveal!.resultsByPlayerId[playerId],
                cumulativePoints:
                  state.scoreboardByPlayerId[playerId]?.points ?? 0,
              })),
            };
          })();

    return {
      phase: state.phase,
      players,
      lobby: {
        readyCount,
        playerCount: state.playerOrder.length,
        canStartMatch,
        settings: {
          totalRounds: state.totalRounds,
          roundDurationSec: state.roundDurationSec,
          revealDurationSec: state.revealDurationSec,
        },
        songBuckets: bucketSelection,
      },
      progress: {
        completedRoundCount: state.completedRoundCount,
        totalRounds: state.totalRounds,
        playedSongCount: state.playedSongKeys.length,
      },
      round,
      reveal,
      finalRankingPlayerIds: [...state.finalRankingPlayerIds],
      availableActions: [
        "set_ready",
        "toggle_song_bucket",
        "start_match",
        "submit_guess",
        "reset_lobby",
        "host:force_game_over",
      ],
    };
  },
  actions: {
    set_ready: agentAction.participant(
      {
        actionName: "setReady",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.boolean({
          payloadDescription: "Whether this controller should be ready.",
        }),
        toPayload: (ready) => ({ ready }),
        description:
          "Mark the current controller as ready or unready in the lobby.",
        availability: "Lobby only. Requires a connected controller identity.",
        resultDescription:
          "The current controller's readiness updates in the lobby roster.",
      },
    ),
    toggle_song_bucket: agentAction.participant(
      {
        actionName: "toggleSongBucket",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.enum(defaultSelectedSongBucketIds, {
          payloadDescription: "The song bucket id to toggle.",
        }),
        toPayload: (bucketId) => ({ bucketId }),
        description:
          "Toggle one song bucket on or off from the lobby settings carousel.",
        availability: "Lobby only.",
        resultDescription:
          "The lobby song bucket selection updates immediately.",
      },
    ),
    start_match: agentAction.participant(
      {
        actionName: "startMatch",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.none(),
        description:
          "Start the match from the lobby once all active players are ready.",
        availability:
          "Lobby only. Controllers can start when they are ready and all ready checks pass.",
        resultDescription:
          "The game enters match countdown and then progresses into the first round.",
      },
    ),
    submit_guess: agentAction.participant(
      {
        actionName: "submitGuess",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.string({
          payloadDescription:
            "The current round option id to submit. Read `round.options` from the game snapshot first.",
        }),
        toPayload: (optionId) => ({ optionId }),
        description:
          "Submit one answer option during an active round using an option id from the current snapshot.",
        availability:
          "Active round only. One submission per controller per round.",
        resultDescription:
          "The controller's answer is locked in for the current round.",
      },
    ),
    reset_lobby: agentAction.participant(
      {
        actionName: "resetLobby",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.none(),
        description:
          "Return the match to a clean lobby state without restarting dev.",
        availability: "Any phase.",
        resultDescription:
          "The match returns to the lobby and clears current round progress.",
      },
    ),
    force_game_over: agentAction.host(
      {
        actionName: "forceGameOver",
        storeDomain: DEFAULT_STORE_DOMAIN,
      },
      {
        input: agentActionInput.none(),
        description:
          "Finish the current match immediately and transition to the final game-over state.",
        availability:
          "Host-side staging only. Visual proof and deterministic QA helper.",
        resultDescription:
          "The current match ends immediately and the game-over screen becomes available.",
      },
    ),
  },
});
