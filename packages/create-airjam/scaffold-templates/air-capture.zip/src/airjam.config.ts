import { defineAirJamGame } from "@air-jam/sdk/core";
import { defineAirJamGameMetadata } from "@air-jam/sdk/metadata";
import { airCaptureAssets } from "./game/assets";
import { agentContract } from "./game/contracts/agent";
import {
  airCaptureInput,
  airCaptureInputBindings,
} from "./game/contracts/input";
import { AIR_CAPTURE_PREFABS } from "./game/prefabs/catalog";
import { prototypeMatchStore } from "./game/stores/match/match-store";
import { airCaptureTheme } from "./game/theme";

import { airCaptureSettings } from "./game/contracts/settings";
export const airjam = defineAirJamGame({
  assets: airCaptureAssets,
  prefabs: AIR_CAPTURE_PREFABS,
  theme: airCaptureTheme,
  metadata: defineAirJamGameMetadata({
    slug: "air-capture",
    name: "Air Capture",
    tagline:
      "Advanced 3D arena battler with ships, rockets, flags, physics, bots, and remote audio.",
    category: "arcade",
    minPlayers: 1,
    maxPlayers: 4,
    inputModalities: ["buttons", "joystick", "touch"],
    supportedSdkRange: "^1.0.0",
    maintainer: { name: "Air Jam" },
    ageRating: "all-ages",
    tags: ["3d", "physics", "capture-the-flag"],
  }),
  controllerPath: "/controller",
  settings: airCaptureSettings,
  stores: [prototypeMatchStore],
  // Loaded on the host only: it brings the Rapier physics engine.
  simulation: () =>
    import("./game/simulation/air-capture-simulation").then(
      (module) => module.airCaptureSimulation,
    ),
  agent: agentContract,
  testing: "./testing/profiles.ts",
  input: airCaptureInput,
  inputBindings: airCaptureInputBindings,
});
