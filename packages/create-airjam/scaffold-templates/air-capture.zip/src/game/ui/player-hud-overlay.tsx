import {
  useAirJamSettings,
  useSimulation,
  useSimulationSelector,
} from "@air-jam/sdk";
import { memo, useEffect, useRef } from "react";
import { PerspectiveCamera, Vector3 } from "three";
import { shallow } from "zustand/shallow";
import { getAbilityIconPath, type AbilityId } from "../abilities/definitions";
import { airCaptureSettings } from "../contracts/settings";
import { cn } from "../debug/ui/utils";
import { createPlayerFlightState } from "../engine/ships/flight";
import { type AirCaptureSim } from "../simulation/state";
import { airCaptureTheme } from "../theme";

const shipIdsOf = (sim: AirCaptureSim) => [...sim.ships.keys()];

// --- CONFIGURATION ---
const HUD_CONFIG = {
  OFFSET_Y: 4, // Units below the ship
  WIDTH: 80, // Width of HUD in px
  COLORS: {
    HIGH: airCaptureTheme.colors.high, // Green (>60%)
    MID: airCaptureTheme.colors.mid, // Yellow (>30%)
    LOW: airCaptureTheme.colors.low, // Red
  },
};

// --- TYPES ---
interface HUDVisualsProps {
  health: number;
  maxHealth: number;
  abilityId?: AbilityId;
  isAbilityActive: boolean;
  energyBarRef?: React.RefObject<HTMLDivElement | null>;
  energyFillRef?: React.RefObject<HTMLDivElement | null>;
  // Refs for direct DOM manipulation (no re-renders)
  countdownCircleRef?: React.RefObject<SVGCircleElement | null>;
  durationTextRef?: React.RefObject<HTMLDivElement | null>;
}

interface PlayerHUDOverlayProps {
  canvasElement: HTMLCanvasElement | null;
  cameras: Array<{
    camera: PerspectiveCamera;
    viewport: { x: number; y: number; width: number; height: number };
  }>;
}

// ------------------------------------------------------------------
// 1. PRESENTATIONAL COMPONENT (Edit your HTML/CSS here!)
// ------------------------------------------------------------------
const HUDVisuals = memo(
  ({
    health,
    maxHealth,
    abilityId,
    isAbilityActive,
    energyBarRef,
    energyFillRef,
    countdownCircleRef,
    durationTextRef,
  }: HUDVisualsProps) => {
    const healthPercentage = (health / maxHealth) * 100;

    // Color Logic
    const color =
      healthPercentage > 60
        ? HUD_CONFIG.COLORS.HIGH
        : healthPercentage > 30
          ? HUD_CONFIG.COLORS.MID
          : HUD_CONFIG.COLORS.LOW;

    // SVG circle parameters for countdown
    const size = 40; // 10 * 4 (w-10 = 40px)
    const radius = 17;
    const circumference = 2 * Math.PI * radius;

    return (
      <div className="pointer-events-none w-full select-none">
        <div
          ref={energyBarRef}
          className="relative mb-1 h-1.5 w-full overflow-hidden rounded-full bg-cyan-300/18 backdrop-blur-sm"
          style={{ display: "none" }}
        >
          <div
            ref={energyFillRef}
            className="absolute inset-y-0 left-0 rounded-full bg-linear-to-r from-cyan-300 via-sky-300 to-white shadow-[0_0_8px_rgba(125,211,252,0.8)]"
            style={{ width: "100%" }}
          />
        </div>
        {/* Health Bar */}
        <div className="relative mb-1.5 h-5 w-full overflow-hidden rounded bg-white/20 backdrop-blur-sm">
          <div
            className="absolute inset-y-0 left-0 opacity-80 transition-all duration-200 ease-out"
            style={{
              width: `${healthPercentage}%`,
              backgroundColor: color,
              boxShadow: `0 0 10px ${color}`,
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center font-mono text-[10px] font-bold text-white drop-shadow-md">
            {Math.round(health)}/{maxHealth}
          </div>
        </div>

        {/* Ability Icon with Circular Countdown */}
        <div className="relative flex items-center justify-center">
          <div className="relative h-10 w-10">
            {/* Ability Icon */}
            {abilityId && (
              <div
                className={cn(
                  "absolute inset-0 z-10 flex h-full w-full items-center justify-center rounded-full border text-sm transition-all",
                  isAbilityActive ? "border-transparent" : "border-white/20",
                  "bg-white/20",
                )}
              >
                <img
                  src={getAbilityIconPath(abilityId)}
                  alt=""
                  className="h-full w-full rounded-full object-cover"
                />
              </div>
            )}

            {/* Circular Countdown Timer (WoW-style) - Always rendered, visibility controlled via DOM */}
            <svg
              className="absolute inset-0 h-full w-full -rotate-90 transform"
              style={{ zIndex: 5, display: isAbilityActive ? "block" : "none" }}
            >
              {/* Background circle (full circle, semi-transparent) */}
              <circle
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke={airCaptureTheme.colors.hudBackground}
                strokeWidth="3"
              />
              {/* Countdown circle (sweeps clockwise from top) - Updated via ref */}
              <circle
                ref={countdownCircleRef}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke={color}
                strokeWidth="3"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={circumference}
                style={{
                  transition: "stroke-dashoffset 0.1s linear",
                  filter: `drop-shadow(0 0 4px ${color})`,
                }}
              />
            </svg>
          </div>

          {/* Duration Text - Updated via ref */}
          <div
            ref={durationTextRef}
            className="absolute -bottom-4 left-1/2 -translate-x-1/2 font-mono text-[10px] font-bold text-white drop-shadow-md"
            style={{ display: "none" }}
          />
        </div>
      </div>
    );
  },
);

HUDVisuals.displayName = "HUDVisuals";

// ------------------------------------------------------------------
// 2. LOGIC COMPONENT (Handles 3D Tracking & Data Fetching)
// ------------------------------------------------------------------
const PlayerHUDItem = memo(function PlayerHUDItem({
  controllerId,
  canvasElement,
  viewport,
  camera,
}: {
  controllerId: string;
  canvasElement: HTMLCanvasElement | null;
  viewport: { x: number; y: number; width: number; height: number };
  camera: PerspectiveCamera;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const energyBarRef = useRef<HTMLDivElement | null>(null);
  const energyFillRef = useRef<HTMLDivElement | null>(null);
  const countdownCircleRef = useRef<SVGCircleElement | null>(null);
  const durationTextRef = useRef<HTMLDivElement | null>(null);
  const countdownAnimationRef = useRef<number | undefined>(undefined);

  // --- Data Stores ---
  const clock = useSimulation<AirCaptureSim>();
  const health = useSimulationSelector(
    (sim: AirCaptureSim) =>
      sim.ships.get(controllerId)?.health ?? sim.settings.maxHealth,
  );
  const { maxHealth } = useAirJamSettings(airCaptureSettings);
  const ability = useSimulationSelector((sim: AirCaptureSim) => {
    const ship = sim.ships.get(controllerId);
    return ship?.activeAbility ?? ship?.queuedAbility ?? null;
  });
  const isAbilityActive = useSimulationSelector((sim: AirCaptureSim) =>
    Boolean(sim.ships.get(controllerId)?.activeAbility),
  );

  // Update countdown circle and duration text via direct DOM manipulation (no re-renders)
  useEffect(() => {
    if (!isAbilityActive || !ability || ability.duration === 0) {
      // Hide countdown when not active
      if (countdownCircleRef.current) {
        countdownCircleRef.current.style.display = "none";
      }
      if (durationTextRef.current) {
        durationTextRef.current.style.display = "none";
      }
      if (countdownAnimationRef.current) {
        cancelAnimationFrame(countdownAnimationRef.current);
        countdownAnimationRef.current = undefined;
      }
      return;
    }

    // Start countdown animation loop
    const updateCountdown = () => {
      const { sim } = clock;
      const currentAbility = sim.ships.get(controllerId)?.activeAbility ?? null;

      if (
        !currentAbility ||
        currentAbility.startTime === null ||
        currentAbility.duration === 0
      ) {
        if (countdownCircleRef.current) {
          countdownCircleRef.current.style.display = "none";
        }
        if (durationTextRef.current) {
          durationTextRef.current.style.display = "none";
        }
        return;
      }

      const remaining =
        currentAbility.duration - (sim.time - currentAbility.startTime);
      const totalDuration = currentAbility.duration;

      if (remaining <= 0) {
        if (countdownCircleRef.current) {
          countdownCircleRef.current.style.display = "none";
        }
        if (durationTextRef.current) {
          durationTextRef.current.style.display = "none";
        }
        return;
      }

      // Update countdown circle
      if (countdownCircleRef.current) {
        const radius = 17;
        const circumference = 2 * Math.PI * radius;
        const percentage = (remaining / totalDuration) * 100;
        const offset = circumference - (percentage / 100) * circumference;
        countdownCircleRef.current.style.strokeDashoffset = `${offset}`;
        countdownCircleRef.current.style.display = "block";
      }

      // Update duration text
      if (durationTextRef.current) {
        const seconds = Math.ceil(remaining);
        durationTextRef.current.textContent = `${seconds}s`;
        durationTextRef.current.style.display = "block";
      }

      countdownAnimationRef.current = requestAnimationFrame(updateCountdown);
    };

    countdownAnimationRef.current = requestAnimationFrame(updateCountdown);

    return () => {
      if (countdownAnimationRef.current) {
        cancelAnimationFrame(countdownAnimationRef.current);
        countdownAnimationRef.current = undefined;
      }
    };
  }, [clock, controllerId, isAbilityActive, ability]);

  // --- 3D Position Tracking (Runs outside React Render Cycle) ---
  // We use Refs for values accessed inside requestAnimationFrame to avoid stale closures
  const cameraRef = useRef(camera);
  const viewportRef = useRef(viewport);

  useEffect(() => {
    cameraRef.current = camera;
    viewportRef.current = viewport;
  }, [camera, viewport]);

  useEffect(() => {
    if (!canvasElement) return;

    let animId: number;
    const updatePosition = () => {
      const element = containerRef.current;
      const energyBar = energyBarRef.current;
      const ship = clock.sim.ships.get(controllerId);
      const shipPos = ship?.position;
      const energyFill = energyFillRef.current;
      const flightState = ship?.flight ?? createPlayerFlightState();

      if (energyBar) {
        energyBar.style.display =
          flightState.mode === "airborne" ? "block" : "none";
      }
      if (energyFill) {
        energyFill.style.width = `${Math.round(flightState.airControlEnergy * 100)}%`;
        energyFill.style.opacity = flightState.isAirControlDepleted
          ? "0.55"
          : "1";
      }

      if (!element || !shipPos) {
        if (element) element.style.display = "none";
        animId = requestAnimationFrame(updatePosition);
        return;
      }

      // 1. World Position (Offset)
      const worldPos = new Vector3(
        shipPos.x,
        shipPos.y - HUD_CONFIG.OFFSET_Y,
        shipPos.z,
      );

      // 2. Project to Normalized Device Coordinates (NDC)
      // Standard Three.js projection: Result is x/y between -1 and 1
      const vector = worldPos.clone().project(cameraRef.current);

      // 3. Visibility Check (Frustum Culling)
      // z > 1 means behind far plane, z < -1 means behind near plane
      // Usually checking if z < 1 (in front of far plane) and z > -1 (not clipped) is enough.
      const isVisible = vector.z < 1 && vector.z > -1;

      if (isVisible) {
        const vp = viewportRef.current;

        // 4. Convert NDC to Screen Pixels (Relative to the specific Viewport)
        const x = (vector.x * 0.5 + 0.5) * vp.width;
        const y = (vector.y * -0.5 + 0.5) * vp.height; // Flip Y for HTML

        // 5. Bounds Check (Is it actually inside the player's split screen?)
        if (x >= 0 && x <= vp.width && y >= 0 && y <= vp.height) {
          element.style.display = "block";
          element.style.transform = `translate(${x}px, ${y}px) translate(-50%, -50%)`;
        } else {
          element.style.display = "none";
        }
      } else {
        element.style.display = "none";
      }

      animId = requestAnimationFrame(updatePosition);
    };

    animId = requestAnimationFrame(updatePosition);
    return () => cancelAnimationFrame(animId);
  }, [clock, controllerId, canvasElement]);

  return (
    <div
      ref={containerRef}
      className="pointer-events-none absolute z-10 w-[80px] select-none"
      style={{
        display: "none", // Hidden by default, shown when visible
      }}
    >
      <HUDVisuals
        health={health}
        maxHealth={maxHealth}
        abilityId={ability?.id}
        isAbilityActive={isAbilityActive}
        energyBarRef={energyBarRef}
        energyFillRef={energyFillRef}
        countdownCircleRef={countdownCircleRef}
        durationTextRef={durationTextRef}
      />
    </div>
  );
});

// ------------------------------------------------------------------
// 3. CONTAINER COMPONENT (Maps Players to Viewports)
// ------------------------------------------------------------------
export const PlayerHUDOverlay = memo(function PlayerHUDOverlay({
  canvasElement,
  cameras,
}: PlayerHUDOverlayProps) {
  const players = useSimulationSelector(shipIdsOf, shallow);

  // Don't render anything if no players
  if (players.length === 0 || !canvasElement) return null;

  // Get canvas dimensions for viewport positioning
  // Use getBoundingClientRect() to get CSS dimensions (viewport coords are in CSS pixels)
  const canvasRect = canvasElement.getBoundingClientRect();
  const canvasHeight = canvasRect.height;

  return (
    <>
      {players.map((player, index) => {
        const cameraData = cameras[index];
        if (!cameraData) return null;

        const { camera, viewport } = cameraData;

        // Convert WebGL viewport coordinates to HTML coordinates
        // WebGL: y=0 at bottom, HTML: y=0 at top
        // So we need to flip the y coordinate
        const htmlY = canvasHeight - viewport.y - viewport.height;

        return (
          <div
            key={player}
            className="pointer-events-none absolute z-10"
            style={{
              left: `${viewport.x}px`,
              top: `${htmlY}px`,
              width: `${viewport.width}px`,
              height: `${viewport.height}px`,
            }}
          >
            <PlayerHUDItem
              controllerId={player}
              canvasElement={canvasElement}
              viewport={viewport}
              camera={camera}
            />
          </div>
        );
      })}
    </>
  );
});
