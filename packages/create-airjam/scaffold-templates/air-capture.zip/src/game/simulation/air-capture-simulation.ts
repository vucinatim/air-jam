import type { AirCaptureSettings } from "../contracts/settings";
import { TEAM_CONFIG, TEAM_IDS } from "../domain/team";
/**
 * Air Capture's authoritative simulation, stepped by the SDK clock on the
 * host. It owns the whole match: the physics world, ships, weapons, pickups,
 * jump pads, flags and scoring, bots and the countdown. The 3D scene only
 * draws it and turns its events into sound, haptics and effects, so the
 * match also runs headless and faster than real time.
 */
import { defineAirJamSimulation } from "@air-jam/sdk/core";
import type { BotWorld } from "../bot-system/bot-world";
import type { GameLoopInput } from "../contracts/input";
import { generateRandomBasePositions } from "../domain/capture-the-flag";
import { createInitialCaptureTheFlagState } from "../stores/match/capture-the-flag-store-state";
import { prototypeMatchStore } from "../stores/match/match-store";
import { emptyTeamSets, stepArena } from "./arena";
import { stepLasers, stepRockets } from "./combat";
import {
  decideMatch,
  followMatchPhase,
  isMatchActive,
  syncRoster,
} from "./match";
import { createArenaPhysics, enforceArenaBounds } from "./physics";
import {
  beginShipStep,
  expireAbility,
  flyShip,
  readShipPosition,
  resolveDeathsAndRespawns,
} from "./ships";
import type { AirCaptureEvent, AirCaptureSim } from "./state";

export const AIR_CAPTURE_STEP_MS = 1000 / 60;

/** Everything a pilot knows about the arena, as plain data; bots and agents read it. */
export const readArena = (sim: AirCaptureSim): BotWorld => ({
  jumpForce: sim.settings.jumpForce,
  ships: [...sim.ships.values()].map((ship) => ({
    controllerId: ship.controllerId,
    teamId: sim.ctf.playerTeams[ship.controllerId] ?? ship.teamId,
    position: [ship.position.x, ship.position.y, ship.position.z],
    rotation: {
      x: ship.rotation.x,
      y: ship.rotation.y,
      z: ship.rotation.z,
      w: ship.rotation.w,
    },
    health: ship.health,
    queuedAbility: ship.queuedAbility?.id ?? null,
  })),
  flags: Object.values(sim.ctf.flags).map((flag) => ({
    teamId: flag.teamId,
    status: flag.status,
    position: [...flag.position],
    ...(flag.carrierId ? { carrierId: flag.carrierId } : {}),
  })),
  basePositions: { ...sim.ctf.basePositions },
  collectibles: [...sim.collectibles.values()].map((collectible) => ({
    id: collectible.id,
    type: "box" as const,
    position: collectible.position,
    timestamp: collectible.spawnedAt,
    abilityId: collectible.abilityId,
  })),
});

const TURN_DEADZONE = 0.08;

/**
 * A pilot's stick in the flight model's terms, where positive y climbs: the
 * stick's y runs down the screen, so pushing it up climbs. A thumb resting
 * slightly off centre does not turn the ship.
 */
const pilotInput = (input: GameLoopInput): GameLoopInput => ({
  ...input,
  vector: {
    x: Math.abs(input.vector.x) < TURN_DEADZONE ? 0 : input.vector.x,
    y: -input.vector.y,
  },
});

/** During the countdown ships may turn but not thrust, fire or use abilities. */
const countdownInput = (input: GameLoopInput): GameLoopInput => ({
  ...input,
  vector: { x: input.vector.x, y: 0 },
  action: false,
  ability: false,
});

export const airCaptureSimulation = defineAirJamSimulation<
  AirCaptureSim,
  GameLoopInput,
  AirCaptureEvent,
  AirCaptureSettings
>({
  moment: (event) => {
    if (event.type === "match-started") return "Match started";
    if (event.type === "team-scored")
      return `${TEAM_CONFIG[event.teamId].label} scored, ${TEAM_IDS.map((id) => event.scores[id]).join(" to ")}`;
    if (event.type === "match-won")
      return `${TEAM_CONFIG[event.teamId].label} won the match`;
    return null;
  },
  stepMs: AIR_CAPTURE_STEP_MS,
  create: ({ random, settings }) => ({
    settings,
    physics: createArenaPhysics(AIR_CAPTURE_STEP_MS / 1000),
    time: 0,
    ships: new Map(),
    lasers: new Map(),
    rockets: new Map(),
    collectibles: new Map(),
    lastCollectibleSpawnAt: 0,
    ctf: createInitialCaptureTheFlagState(generateRandomBasePositions(random)),
    baseOccupants: emptyTeamSets(),
    flagContacts: emptyTeamSets(),
    jumpPadContacts: new Map(),
    jumpPadCooldownUntil: new Map(),
    roundId: 0,
    matchPhase: prototypeMatchStore.getState().matchPhase,
    countdownStartedAt: null,
    roster: "",
    nextEntityId: 0,
  }),
  step: (sim, context) => {
    sim.settings = context.settings;
    syncRoster(sim, context.players, context.random, context.emit);
    followMatchPhase(sim, context.random, context.emit);
    if (!isMatchActive(sim.matchPhase)) return;

    const delta = context.dtSeconds;
    sim.time += delta;
    const arena = [...sim.ships.values()].some((ship) => ship.bot)
      ? readArena(sim)
      : null;
    for (const ship of sim.ships.values()) {
      beginShipStep(ship);
      expireAbility(sim, ship);
      if (ship.dead) continue;
      const raw =
        ship.bot && arena
          ? ship.bot.update(sim.time, arena)
          : pilotInput(context.input(ship.controllerId));
      const input = sim.matchPhase === "countdown" ? countdownInput(raw) : raw;
      flyShip(sim, ship, input, delta, context.emit);
    }
    sim.physics.world.step();
    enforceArenaBounds(sim.physics);
    for (const ship of sim.ships.values()) readShipPosition(ship);
    stepLasers(sim, delta, context.emit);
    stepRockets(sim, delta, context.emit);
    stepArena(sim, context.random, context.emit);
    resolveDeathsAndRespawns(sim, context.emit);
    decideMatch(sim, context.emit);
  },
  // The arena lives in the simulation; agents read the same snapshot bots fly by.
  observe: (sim) => ({ ...readArena(sim), scores: { ...sim.ctf.scores } }),
});
