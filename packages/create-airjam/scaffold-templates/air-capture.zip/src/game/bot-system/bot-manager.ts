import { nanoid } from "nanoid";
import { create } from "zustand";
import type { GameLoopInput } from "../contracts/input";
import { useGameStore } from "../stores/players/game-store";
import { BotController } from "./bot-controller";
import { readBotWorld } from "./bot-world";

interface BotManagerState {
  bots: Map<string, BotController>;
  addBot: () => string;
  getBotInput: (
    controllerId: string,
    _delta: number,
    time: number,
  ) => GameLoopInput | undefined;
  removeBot: (controllerId: string) => void;
}

export const useBotManager = create<BotManagerState>((set, get) => ({
  bots: new Map(),

  addBot: () => {
    const controllerId = `bot-${nanoid(6)}`;
    const bot = new BotController(controllerId);

    set((state) => {
      const newBots = new Map(state.bots);
      newBots.set(controllerId, bot);
      return { bots: newBots };
    });

    // Add to GameStore as a player
    useGameStore.getState().upsertBotPlayer(
      {
        id: controllerId,
        label: `Bot ${controllerId.slice(4)}`,
        // Bots don't have avatars yet, maybe use a default or random one if needed
        // For now, the profile just needs a label
      },
      controllerId,
    );

    return controllerId;
  },

  getBotInput: (controllerId, _delta, time) => {
    const bot = get().bots.get(controllerId);
    if (!bot) return undefined;
    return bot.update(time, readBotWorld());
  },

  removeBot: (controllerId) => {
    set((state) => {
      const newBots = new Map(state.bots);
      newBots.delete(controllerId);
      return { bots: newBots };
    });
    useGameStore.getState().removeBotPlayer(controllerId);
  },
}));
