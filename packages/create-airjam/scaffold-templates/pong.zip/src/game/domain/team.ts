import { pongTheme } from "../theme";
/**
 * Team identity + static presentation (label, color).
 *
 * Kept as domain-pure constants so both the host canvas renderer and the
 * controller UI read the same source of truth.
 */
export type TeamId = "team1" | "team2";

export const TEAMS: Record<
  TeamId,
  {
    id: TeamId;
    label: string;
    color: string;
  }
> = {
  team1: {
    id: "team1",
    label: "Sołaris",
    color: pongTheme.colors.team1,
  },
  team2: {
    id: "team2",
    label: "Nebułon",
    color: pongTheme.colors.team2,
  },
};

export const oppositeTeam = (team: TeamId): TeamId =>
  team === "team1" ? "team2" : "team1";

export const getTeamLabel = (team: TeamId): string => TEAMS[team].label;

export const getTeamColor = (team: TeamId): string => TEAMS[team].color;
